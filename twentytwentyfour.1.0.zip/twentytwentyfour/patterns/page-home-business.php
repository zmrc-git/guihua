<?php
/**
 * Title: Business home
 * Slug: twentytwentyfour/page-home-business
 * Categories: page
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 * Viewport width: 1400
 */
?>

<!-- wp:pattern {"slug":"twentytwentyfour/banner-hero"} /-->
<!-- wp:pattern {"slug":"twentytwentyfour/text-feature-grid-3-col"} /-->
<!-- wp:pattern {"slug":"twentytwentyfour/text-alternating-images"} /-->
<!-- wp:pattern {"slug":"twentytwentyfour/testimonial-centered"} /-->
<!-- wp:pattern {"slug":"twentytwentyfour/posts-list"} /-->
<!-- wp:pattern {"slug":"twentytwentyfour/cta-subscribe-centered"} /-->
